#
#  GoogleFindMyTools - A set of tools to interact with the Google Find My API
#  Copyright © 2024 Leon Böttger. All rights reserved.
#

from selenium.webdriver.support.ui import WebDriverWait
from chrome_driver import create_driver, safe_quit_driver

def request_oauth_account_token_flow(driver=None):
    owns_driver = driver is None

    print("""[AuthFlow] This script will use Google Chrome to login to your Google account.
> Please make sure that Chrome is installed on your system.
> For macOS users only: Make that you allow Python (or PyCharm) to control Chrome if prompted. 
    """)

    if owns_driver:
        input("[AuthFlow] Press Enter to continue...")

    # Automatically install and set up the Chrome driver
    if owns_driver:
        print("[AuthFlow] Installing ChromeDriver...")

    if owns_driver:
        driver = create_driver()

    try:
        # Open the browser and navigate to the URL
        driver.get("https://accounts.google.com/EmbeddedSetup")

        # Wait until the "oauth_token" cookie is set
        print("[AuthFlow] Waiting for 'oauth_token' cookie to be set...")
        WebDriverWait(driver, 300).until(
            lambda d: d.get_cookie("oauth_token") is not None
        )

        # Get the value of the "oauth_token" cookie
        oauth_token_cookie = driver.get_cookie("oauth_token")
        oauth_token_value = oauth_token_cookie['value']

        # Print the value of the "oauth_token" cookie
        print("[AuthFlow] Retrieved Account Token successfully.")

        return oauth_token_value

    finally:
        # Close the browser
        if owns_driver:
            safe_quit_driver(driver)

if __name__ == '__main__':
    request_oauth_account_token_flow()
