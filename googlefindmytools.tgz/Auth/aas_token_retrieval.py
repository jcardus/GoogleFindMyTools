#
#  GoogleFindMyTools - A set of tools to interact with the Google Find My API
#  Copyright © 2024 Leon Böttger. All rights reserved.
#

import gpsoauth

from Auth.auth_flow import request_oauth_account_token_flow
from Auth.auth_response import require_response_field
from Auth.fcm_receiver import FcmReceiver
from Auth.token_cache import get_cached_value_or_set, set_cached_value
from Auth.username_provider import get_username, username_string


def _generate_aas_token(driver=None):
    username = get_username()
    android_id = FcmReceiver().get_android_id()
    token = request_oauth_account_token_flow(driver)

    aas_token_response = gpsoauth.exchange_token(username, token, android_id)
    aas_token = require_response_field(
        aas_token_response,
        'Token',
        'AAS token exchange'
    )

    if 'Email' in aas_token_response:
        email = aas_token_response['Email']
        set_cached_value(username_string, email)

    return aas_token


def get_aas_token(driver=None):
    return get_cached_value_or_set('aas_token', lambda: _generate_aas_token(driver))


if __name__ == '__main__':
    print(get_aas_token())
