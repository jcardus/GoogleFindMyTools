import argparse
import datetime
import hashlib
import logging
import threading
import time
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from python_version import require_python_312

require_python_312()

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger('hub')

from supabase import Client, create_client

from NovaApi.ListDevices.nbe_list_devices import request_device_list
from ProtoDecoders.decoder import parse_device_list_protobuf, parse_device_update_protobuf
from NovaApi.ExecuteAction.LocateTracker.location_request import create_location_request
from NovaApi.nova_request import nova_request
from NovaApi.scopes import NOVA_ACTION_API_SCOPE
from NovaApi.util import generate_random_uuid
from Auth.adm_token_retrieval import get_adm_token
from Auth.auth_response import GoogleAuthError
from Auth.fcm_receiver import FcmReceiver
from Auth.username_provider import get_username
from FMDNCrypto.eid_generator import generate_eid
from FMDNCrypto.foreign_tracker_cryptor import decrypt
from KeyBackup.cloud_key_decryptor import decrypt_aes_gcm
from ProtoDecoders import Common_pb2
from ProtoDecoders.DeviceUpdate_pb2 import DevicesList, Location
from SpotApi.UploadPrecomputedPublicKeyIds.upload_precomputed_public_key_ids import refresh_custom_trackers
from NovaApi.ExecuteAction.LocateTracker.decrypt_locations import is_mcu_tracker, retrieve_identity_key

SB: Optional[Client] = None
EID_REFRESH_INTERVAL = int(os.getenv('EID_REFRESH_INTERVAL', str(3 * 24 * 60 * 60)))
EID_REFRESH_STATE_FILE = os.getenv('EID_REFRESH_STATE_FILE')
LOCATION_REQUEST_TIMEOUT = float(os.getenv('GOOGLE_LOCATION_TIMEOUT', '15'))
SYNC_CONCURRENCY = min(10, max(1, int(os.getenv('GOOGLE_SYNC_CONCURRENCY', '1'))))
AUTH_FAILURE_EXIT_CODE = 2
GOOGLE_ACCOUNT: Optional[str] = None  # set at startup; None means no filter (default account)
_last_eid_refresh_at = 0.0


def _validate_google_auth():
    google_account = GOOGLE_ACCOUNT or get_username()
    try:
        get_adm_token(google_account)
    except GoogleAuthError as e:
        log.error(
            'Google authentication failed before sync (google_account=%s): %s',
            google_account,
            e,
        )
        return False
    log.info(
        'Google authentication ready for android_device_manager '
        '(google_account=%s)',
        google_account,
    )
    return True


def _google_account_secrets_r2_key(google_account):
    prefix = os.getenv('GOOGLE_SECRETS_R2_PREFIX', 'google-secrets').strip('/')
    account_key = quote(google_account, safe='@._-+')
    return f'{prefix}/{account_key}.json' if prefix else f'{account_key}.json'


def _sync_detail(message, skipped):
    if skipped:
        return f'{message}, {skipped} skipped (MAC check failed)'
    return message


def _extract_locations(device_update, tag_id=None):
    device_registration = device_update.deviceMetadata.information.deviceRegistration
    identity_key = retrieve_identity_key(device_registration)
    locations_proto = device_update.deviceMetadata.information.locationInformation.reports.recentLocationAndNetworkLocations
    is_mcu = is_mcu_tracker(device_registration)

    locations = []
    semantic_locations = []
    skipped = 0
    network_locations = list(locations_proto.networkLocations)
    network_timestamps = list(locations_proto.networkLocationTimestamps)

    if locations_proto.HasField('recentLocation'):
        network_locations.append(locations_proto.recentLocation)
        network_timestamps.append(locations_proto.recentLocationTimestamp)

    for loc, timestamp in zip(network_locations, network_timestamps):
        if loc.status == Common_pb2.Status.SEMANTIC:
            if loc.semanticLocation.locationName:
                semantic_locations.append({
                    'name': loc.semanticLocation.locationName,
                    'time': int(timestamp.seconds),
                })
            continue

        encrypted_location = loc.geoLocation.encryptedReport.encryptedLocation
        public_key_random = loc.geoLocation.encryptedReport.publicKeyRandom

        try:
            if public_key_random == b'':
                identity_key_hash = hashlib.sha256(identity_key).digest()
                decrypted_location = decrypt_aes_gcm(identity_key_hash, encrypted_location)
            else:
                time_offset = 0 if is_mcu else loc.geoLocation.deviceTimeOffset
                decrypted_location = decrypt(identity_key, encrypted_location, public_key_random, time_offset)
        except ValueError as exc:
            if str(exc) != 'MAC check failed':
                raise
            skipped += 1
            log.warning(
                '%s skipping location report ts=%s: MAC check failed',
                tag_id or '(unknown)',
                int(timestamp.seconds),
            )
            continue

        parsed = Location()
        parsed.ParseFromString(decrypted_location)
        locations.append({
            'latitude': parsed.latitude / 1e7,
            'longitude': parsed.longitude / 1e7,
            'altitude': parsed.altitude,
            'time': int(timestamp.seconds),
            'accuracy': loc.geoLocation.accuracy,
            'is_own_report': loc.geoLocation.encryptedReport.isOwnReport,
        })

    return locations, semantic_locations, skipped


def _percentile(values, pct):
    ordered = sorted(values)
    rank = max(1, int(round(pct / 100 * len(ordered))))
    return ordered[min(rank, len(ordered)) - 1]


def _format_push_timing(label, values):
    if not values:
        return f'{label}: none'
    return (
        f'{label}: n={len(values)} p50 {_percentile(values, 50):.3f}s '
        f'p95 {_percentile(values, 95):.3f}s max {max(values):.3f}s'
    )


def _fetch_location(device_id, fcm_token, pending_requests, pending_lock,
                    timeout=LOCATION_REQUEST_TIMEOUT, tag_id=None, queued_at=None):
    started = time.monotonic()
    queue_s = max(0.0, started - queued_at) if queued_at is not None else 0.0
    request_uuid = generate_random_uuid()
    done = threading.Event()
    response = {}
    request_s = 0.0
    wait_s = 0.0
    timed_out = False

    with pending_lock:
        pending_requests[request_uuid] = (done, response)

    request_started = time.monotonic()
    response['sent_at'] = request_started
    try:
        payload = create_location_request(device_id, fcm_token, request_uuid)
        nova_request(NOVA_ACTION_API_SCOPE, payload)
        request_s = time.monotonic() - request_started
        wait_started = time.monotonic()
        if not done.wait(timeout):
            timed_out = True
            wait_s = time.monotonic() - wait_started
            log.info(
                '%s location request timed out after %.1fs (request %.1fs, queued %.1fs)',
                tag_id or request_uuid,
                wait_s,
                request_s,
                queue_s,
            )
        else:
            wait_s = time.monotonic() - wait_started
    finally:
        with pending_lock:
            pending_requests.pop(request_uuid, None)

    arrived_at = response.get('arrived_at')
    push_s = None
    after_http_s = None
    if arrived_at is not None:
        push_s = max(0.0, arrived_at - request_started)
        after_http_s = max(0.0, arrived_at - wait_started)

    decrypt_started = time.monotonic()
    result = response.get('update')
    if result:
        locations, semantic_locations, skipped = _extract_locations(result, tag_id)
    else:
        locations, semantic_locations, skipped = [], [], 0
    timing = {
        'queue_s': queue_s,
        'request_s': request_s,
        'wait_s': wait_s,
        'push_s': push_s,
        'after_http_s': after_http_s,
        'decrypt_s': time.monotonic() - decrypt_started,
        'timed_out': timed_out,
    }
    return locations, semantic_locations, skipped, timing


def _create_location_dispatcher(pending_requests, pending_lock):
    def handler(resp_hex):
        try:
            update = parse_device_update_protobuf(resp_hex)
            request_uuid = update.fcmMetadata.requestUuid
            with pending_lock:
                pending = pending_requests.get(request_uuid)
                if pending:
                    done, response = pending
                    response['arrived_at'] = time.monotonic()
                    response['update'] = update
                    done.set()
        except Exception:
            log.exception('could not route FCM location response')

    return handler


def _log_sync(tag_id, status, message):
    if SB is None:
        return
    try:
        SB.table('hybrid_tags').update({
            'last_google_sync_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'last_google_sync_status': status,
            'last_google_sync_message': message[:1000],
        }).eq('tag_id', tag_id).execute()
    except Exception:
        log.exception('%s failed to write sync log', tag_id)


def _log_semantic_location(tag_id, name, time_seconds):
    if SB is None:
        return
    try:
        ts = datetime.datetime.fromtimestamp(time_seconds, tz=datetime.timezone.utc).isoformat()
        SB.table('hybrid_tags').update({
            'last_google_semantic_location': name[:1000],
            'last_google_semantic_location_at': ts,
        }).eq('tag_id', tag_id).execute()
    except Exception:
        log.exception('%s failed to write semantic location', tag_id)


def _log_eid_refresh(status, message):
    if SB is None or GOOGLE_ACCOUNT is None:
        return
    try:
        SB.table('google_accounts').update({
            'last_eid_refresh_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'last_eid_refresh_status': status,
            'last_eid_refresh_message': message[:1000],
        }).eq('google_account', GOOGLE_ACCOUNT).execute()
    except Exception:
        log.exception('failed to write EID refresh log for %s', GOOGLE_ACCOUNT)


def _upload_location(device_id, tag_id, user_id, location):
    if SB is None:
        raise RuntimeError('Supabase client not configured')
    if not location:
        return False

    ts = datetime.datetime.fromtimestamp(float(location['time']), tz=datetime.timezone.utc).isoformat()
    row = {
        'tag_id': tag_id,
        'user_id': user_id,
        'lat': location['latitude'],
        'lon': location['longitude'],
        'accuracy': location.get('accuracy'),
        'source': 'google',
        'timestamp': ts,
    }

    resp = SB.table('positions').upsert(
        row, on_conflict='tag_id,source,timestamp', ignore_duplicates=True,
    ).execute()
    inserted = bool(resp.data)
    log.info(
        '%s upsert ts=%s lat=%s lon=%s -> %s',
        tag_id, ts, location['latitude'], location['longitude'],
        'inserted' if inserted else 'duplicate (ignored)',
    )
    return inserted


def _read_eid_refresh_marker():
    state_file = _eid_refresh_state_file()
    try:
        return float(state_file.read_text().strip())
    except (OSError, ValueError):
        return 0.0


def _write_eid_refresh_marker(timestamp):
    path = _eid_refresh_state_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(timestamp))
    except OSError:
        log.warning('could not write EID refresh marker: %s', path)


def _eid_refresh_state_file():
    if EID_REFRESH_STATE_FILE:
        return Path(EID_REFRESH_STATE_FILE)
    account = GOOGLE_ACCOUNT or 'default'
    account_hash = hashlib.sha256(account.encode()).hexdigest()[:16]
    return Path(f'/tmp/tagora-google-hub-eid-refresh-{account_hash}.txt')


def _should_refresh_eids(now):
    if EID_REFRESH_INTERVAL <= 0:
        return True
    last_refresh = max(_last_eid_refresh_at, _read_eid_refresh_marker())
    age = now - last_refresh
    if age >= EID_REFRESH_INTERVAL:
        return True
    log.info(
        'skipping EID refresh; last refresh was %.0fs ago (interval=%ds)',
        max(age, 0),
        EID_REFRESH_INTERVAL,
    )
    return False


def _fetch_all(query, page_size=1000):
    # PostgREST caps each response at 1000 rows, so page through explicitly;
    # ordering by tag_id keeps pages stable across requests.
    rows = []
    query = query.order('tag_id')
    while True:
        page = query.range(len(rows), len(rows) + page_size - 1).execute().data or []
        rows.extend(page)
        if len(page) < page_size:
            return rows


def _refresh_eids():
    try:
        if SB is None:
            return False
        query = SB.table('hybrid_tags').select('google_id, google_eik, google_adv_key, google_account, tag_id').filter('google_id', 'not.is', 'null').filter('google_id', 'neq', '')
        if GOOGLE_ACCOUNT is not None:
            query = query.filter('google_account', 'eq', GOOGLE_ACCOUNT)
        rows = _fetch_all(query)
        eik_by_google_id = {r['google_id']: r.get('google_eik') for r in rows}
        adv_key_by_google_id = {r['google_id']: r.get('google_adv_key') for r in rows}
        account_by_google_id = {r['google_id']: r.get('google_account') for r in rows}
        tag_by_google_id = {r['google_id']: r['tag_id'] for r in rows}
        if not eik_by_google_id:
            _log_eid_refresh('ok', 'no known devices with a google_id')
            return True

        log.info(
            'refreshing EID key list with Google (%d known devices, google_account=%s)',
            len(eik_by_google_id),
            GOOGLE_ACCOUNT or '(unfiltered)',
        )
        list_started = time.monotonic()
        result_hex = request_device_list()
        log.info('Google device list returned in %.1fs', time.monotonic() - list_started)
        device_list = parse_device_list_protobuf(result_hex)

        filtered = DevicesList()
        unmatched_google_devices = []
        for d in device_list.deviceMetadata:
            canonic_ids = [c.id for c in d.identifierInformation.canonicIds.canonicId]
            matched_id = next((cid for cid in canonic_ids if cid in eik_by_google_id), None)
            if matched_id is None:
                if canonic_ids:
                    unmatched_google_devices.append((d.userDefinedDeviceName or '(unnamed)', canonic_ids))
                continue
            filtered.deviceMetadata.append(d)
            tag_id = tag_by_google_id.get(matched_id, matched_id)
            google_account = account_by_google_id.get(matched_id) or GOOGLE_ACCOUNT or '(unknown)'
            stored_eik = eik_by_google_id.get(matched_id)
            metadata = _device_metadata_summary(d, matched_id)
            log.info(
                '%s Google metadata: google_id=%s backend_name=%s canonic_ids=%s '
                'pair_date=%s creation_date=%s owner_key_version=%s '
                'encrypted_identity_key_len=%s encrypted_account_key_len=%s '
                'encrypted_public_address_len=%s manufacturer=%s model=%s fast_pair_model_id=%s',
                tag_id,
                metadata['matched_google_id'],
                metadata['backend_name'],
                metadata['canonic_ids'],
                metadata['pair_date'],
                metadata['creation_date'],
                metadata['owner_key_version'],
                metadata['encrypted_identity_key_len'],
                metadata['encrypted_account_key_len'],
                metadata['encrypted_public_address_len'],
                metadata['manufacturer'],
                metadata['model'],
                metadata['fast_pair_model_id'],
            )
            try:
                decrypted_eik = retrieve_identity_key(d.information.deviceRegistration)
                google_eid = generate_eid(decrypted_eik, 0).hex()
                stored_adv_key = adv_key_by_google_id.get(matched_id)
                if stored_eik:
                    match = decrypted_eik.hex() == stored_eik
                    log.info('%s EIK %s (google_account=%s)', tag_id, 'matches Supabase' if match else f'MISMATCH (decrypted={decrypted_eik.hex()[:16]}… stored={stored_eik[:16]}…)', google_account)
                else:
                    log.info('%s EIK decrypted=%s (no stored EIK to compare, google_account=%s)', tag_id, decrypted_eik.hex()[:16] + '…', google_account)
                if stored_adv_key:
                    match = google_eid == stored_adv_key
                    log.info('%s EID %s (google=%s stored=%s google_account=%s)', tag_id, 'matches Supabase' if match else 'MISMATCH', google_eid, stored_adv_key, google_account)
                else:
                    log.info('%s EID google=%s (no stored google_adv_key to compare, google_account=%s)', tag_id, google_eid, google_account)
            except SystemExit:
                log.warning('%s EIK decryption failed (owner key mismatch, google_account=%s)', tag_id, google_account)

        if unmatched_google_devices:
            for device_name, canonic_ids in unmatched_google_devices:
                log.info(
                    'Google device not found in Supabase: name=%s canonic_ids=%s',
                    device_name,
                    ','.join(canonic_ids) if canonic_ids else '(none)',
                )

        log.info(
            'refreshing EIDs for %d matched Supabase device(s); Google returned %d total device(s)',
            len(filtered.deviceMetadata),
            len(device_list.deviceMetadata),
        )
        upload_started = time.monotonic()
        refreshed = refresh_custom_trackers(filtered)
        log.info('EID upload finished in %.1fs', time.monotonic() - upload_started)
        if not refreshed:
            log.warning('EID key list refresh upload failed (google_account=%s)', GOOGLE_ACCOUNT or '(unfiltered)')
            _log_eid_refresh('error', 'EID key list upload to Google failed')
            return False
        log.info('EID key list refreshed (google_account=%s)', GOOGLE_ACCOUNT or '(unfiltered)')
        _log_eid_refresh(
            'ok',
            f'refreshed {len(filtered.deviceMetadata)} matched device(s) of {len(device_list.deviceMetadata)} total',
        )
        return True
    except Exception as e:
        log.exception('EID refresh failed')
        _log_eid_refresh('error', str(e))
        return False


def _device_metadata_summary(device_metadata, matched_id):
    device_registration = device_metadata.information.deviceRegistration
    encrypted_user_secrets = device_registration.encryptedUserSecrets
    canonic_ids = [c.id for c in device_metadata.identifierInformation.canonicIds.canonicId]
    creation_date = encrypted_user_secrets.creationDate.seconds if encrypted_user_secrets.HasField('creationDate') else 0
    return {
        'backend_name': device_metadata.userDefinedDeviceName or '(unnamed)',
        'matched_google_id': matched_id,
        'canonic_ids': ','.join(canonic_ids) if canonic_ids else '(none)',
        'pair_date': device_registration.pairDate,
        'creation_date': creation_date,
        'owner_key_version': encrypted_user_secrets.ownerKeyVersion,
        'encrypted_identity_key_len': len(encrypted_user_secrets.encryptedIdentityKey),
        'encrypted_account_key_len': len(encrypted_user_secrets.encryptedAccountKey),
        'encrypted_public_address_len': len(encrypted_user_secrets.encryptedSha256AccountKeyPublicAddress),
        'manufacturer': device_registration.manufacturer or '(none)',
        'model': device_registration.model or '(none)',
        'fast_pair_model_id': device_registration.fastPairModelId or '(none)',
    }


def _refresh_eids_if_due():
    global _last_eid_refresh_at
    now = time.time()
    if not _should_refresh_eids(now):
        return
    started = time.monotonic()
    if _refresh_eids():
        _last_eid_refresh_at = now
        _write_eid_refresh_marker(now)
    log.info('EID refresh finished in %.1fs', time.monotonic() - started)


def _sync_pass():
    if SB is None:
        log.warning('sync skipped: Supabase client not configured')
        return 0

    _refresh_eids_if_due()
    started = time.monotonic()
    query = SB.table('hybrid_tags') \
        .select('tag_id, user_id, google_id') \
        .filter('google_id', 'not.is', 'null') \
        .filter('google_id', 'neq', '') \
        .filter('user_id', 'not.is', 'null')
    if GOOGLE_ACCOUNT is not None:
        query = query.filter('google_account', 'eq', GOOGLE_ACCOUNT)
    list_started = time.monotonic()
    tags = _fetch_all(query)
    log.info(
        'sync pass start: %d tag(s) listed in %.1fs',
        len(tags),
        time.monotonic() - list_started,
    )
    if not tags:
        return 0

    inserted_count = 0
    no_location_count = 0
    error_count = 0
    completed = 0
    timeout_count = 0
    max_queue_s = request_s = wait_s = decrypt_s = upload_s = 0.0
    push_from_send = []
    push_after_http = []
    slowest = (0.0, None)
    pending_requests = {}
    pending_lock = threading.Lock()
    dispatcher = _create_location_dispatcher(pending_requests, pending_lock)
    receiver = FcmReceiver()
    fcm_started = time.monotonic()
    fcm_token = receiver.register_for_location_updates(dispatcher)
    log.info(
        'FCM listener ready in %.1fs; fetching locations with concurrency=%d',
        time.monotonic() - fcm_started,
        SYNC_CONCURRENCY,
    )

    try:
        with ThreadPoolExecutor(max_workers=SYNC_CONCURRENCY) as executor:
            future_to_tag = {}
            for tag in tags:
                future = executor.submit(
                    _fetch_location,
                    tag['google_id'],
                    fcm_token,
                    pending_requests,
                    pending_lock,
                    LOCATION_REQUEST_TIMEOUT,
                    tag['tag_id'],
                    time.monotonic(),
                )
                future_to_tag[future] = tag

            for future in as_completed(future_to_tag):
                tag = future_to_tag[future]
                gid = tag['google_id']
                tag_id = tag['tag_id']
                completed += 1
                try:
                    locations, semantic_locations, skipped, timing = future.result()
                    upload_started = time.monotonic()
                    usable = [
                        location for location in locations
                        if 'latitude' in location and 'longitude' in location
                    ]
                    if usable:
                        tag_inserted = 0
                        for location in usable:
                            if _upload_location(
                                gid, tag_id, tag['user_id'], location
                            ):
                                inserted_count += 1
                                tag_inserted += 1
                        _log_sync(
                            tag_id,
                            'ok',
                            _sync_detail(
                                f'{len(usable)} location(s), {tag_inserted} inserted',
                                skipped,
                            ),
                        )
                    elif semantic_locations:
                        names = [s['name'] for s in semantic_locations]
                        log.info('%s semantic location(s): %s', tag_id, ', '.join(names))
                        no_location_count += 1
                        _log_sync(
                            tag_id,
                            'semantic',
                            _sync_detail(f'semantic location: {", ".join(names)}', skipped),
                        )
                        latest = max(semantic_locations, key=lambda s: s['time'])
                        _log_semantic_location(tag_id, latest['name'], latest['time'])
                    else:
                        no_location_count += 1
                        _log_sync(
                            tag_id,
                            'no_location',
                            _sync_detail('no usable location in response', skipped),
                        )
                    upload_elapsed = time.monotonic() - upload_started
                    timeout_count += int(timing['timed_out'])
                    if timing['push_s'] is not None:
                        push_from_send.append(timing['push_s'])
                        push_after_http.append(timing['after_http_s'])
                    max_queue_s = max(max_queue_s, timing['queue_s'])
                    request_s += timing['request_s']
                    wait_s += timing['wait_s']
                    decrypt_s += timing['decrypt_s']
                    upload_s += upload_elapsed
                    tag_total = (
                        timing['queue_s'] + timing['request_s'] + timing['wait_s']
                        + timing['decrypt_s'] + upload_elapsed
                    )
                    if tag_total >= slowest[0]:
                        slowest = (tag_total, tag_id)
                    if timing['push_s'] is None:
                        push_text = 'push none'
                    else:
                        push_text = (
                            f'push {timing["push_s"]:.3f}s, '
                            f'after {timing["after_http_s"]:.3f}s'
                        )
                    log.info(
                        '%s %d/%d got %d location(s) in %.1fs '
                        '(queue %.1fs, request %.1fs, %s, wait %.1fs%s, decrypt %.1fs, upload %.1fs)%s',
                        tag_id,
                        completed,
                        len(tags),
                        len(locations),
                        tag_total,
                        timing['queue_s'],
                        timing['request_s'],
                        push_text,
                        timing['wait_s'],
                        ' timeout' if timing['timed_out'] else '',
                        timing['decrypt_s'],
                        upload_elapsed,
                        f', {skipped} skipped' if skipped else '',
                    )
                except Exception as e:
                    error_count += 1
                    log.exception(
                        '%s %d/%d sync error (google_account=%s): %s',
                        tag_id,
                        completed,
                        len(tags),
                        GOOGLE_ACCOUNT or '(unfiltered)',
                        e,
                    )
                    _log_sync(tag_id, 'error', str(e))
    finally:
        receiver.unregister_location_updates(dispatcher)
        receiver.stop_listening()

    elapsed = time.monotonic() - started
    log.info(
        'push timing: %s; %s',
        _format_push_timing('from send', push_from_send),
        _format_push_timing('after HTTP', push_after_http),
    )
    log.info(
        'sync pass done in %.1fs: %d tag(s), %d timeout(s), '
        'max queue %.1fs, request %.1fs, google wait %.1fs, decrypt %.1fs, upload %.1fs, '
        '%d inserted, %d no-location, %d error(s), slowest %s %.1fs',
        elapsed,
        len(tags),
        timeout_count,
        max_queue_s,
        request_s,
        wait_s,
        decrypt_s,
        upload_s,
        inserted_count,
        no_location_count,
        error_count,
        slowest[1] or '(none)',
        slowest[0],
    )
    return error_count


def main():
    parser = argparse.ArgumentParser(description="Google Find Hub Sync")
    parser.add_argument('--secrets-file', default=os.getenv('GOOGLE_SECRETS_FILE'),
                        help='Path to the Google secrets.json for this account. Defaults to Auth/<google-account>.json.')
    parser.add_argument('--google-account',
                        help='Only sync tags whose google_account matches this value')
    args = parser.parse_args()

    secrets_file = args.secrets_file
    if not secrets_file and args.google_account:
        secrets_file = os.path.join('Auth', f'{args.google_account}.json')

    if args.google_account and os.getenv('GOOGLE_SECRETS_R2_BUCKET') and not os.getenv('GOOGLE_SECRETS_R2_KEY'):
        os.environ['GOOGLE_SECRETS_R2_KEY'] = _google_account_secrets_r2_key(args.google_account)

    if secrets_file:
        import Auth.token_cache as _tc
        _tc._get_secrets_file = lambda: secrets_file
        log.info('Using secrets file: %s', secrets_file)
    if os.getenv('GOOGLE_SECRETS_R2_BUCKET') and os.getenv('GOOGLE_SECRETS_R2_KEY'):
        log.info(
            'Using R2 secrets object: %s/%s',
            os.getenv('GOOGLE_SECRETS_R2_BUCKET'),
            os.getenv('GOOGLE_SECRETS_R2_KEY'),
        )

    global GOOGLE_ACCOUNT
    GOOGLE_ACCOUNT = args.google_account
    if GOOGLE_ACCOUNT is not None:
        log.info('Filtering sync to google_account=%s', GOOGLE_ACCOUNT)

    auth_started = time.monotonic()
    if not _validate_google_auth():
        log.error(
            'Google authentication failed after %.1fs',
            time.monotonic() - auth_started,
        )
        sys.exit(AUTH_FAILURE_EXIT_CODE)
    log.info('Google authentication took %.1fs', time.monotonic() - auth_started)

    sb_url = os.getenv('SUPABASE_URL')
    sb_key = os.getenv('SUPABASE_SERVICE_ROLE')
    if not sb_url or not sb_key:
        parser.error('SUPABASE_URL and SUPABASE_SERVICE_ROLE environment variables are required')

    global SB
    SB = create_client(sb_url, sb_key)
    log.info('Supabase client ready (%s)', sb_url)

    log.info('Running single sync pass')
    error_count = _sync_pass()
    sys.exit(1 if error_count else 0)


if __name__ == '__main__':
    main()
