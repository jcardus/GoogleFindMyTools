"""
Provision an existing Google account for the GoogleFindMyTools hub.

This script can run the local Chrome auth flow, upload the resulting auth cache
through the Tagora backend, and let the backend upsert the matching Supabase
google_accounts row.
"""
import argparse
import base64
import getpass
import json
import os
import pathlib
import subprocess
import sys
from typing import Optional

import requests
from requests import HTTPError

from provision_account_auth import infer_google_account, load_secrets
from python_version import require_python_312

require_python_312()

DEFAULT_PROVISIONING_URL = "https://tagora.uk/api/v1/google-accounts/provision"


class ProvisioningUnauthorized(Exception):
    pass


def require_value(name: str, value: Optional[str]) -> str:
    if value and value.strip():
        return value.strip()
    raise SystemExit(f"{name} is required. Pass --{name.replace('_', '-')} or set the matching environment variable.")


def prompt_secret(name: str, value: Optional[str]) -> str:
    if value and value.strip():
        return value.strip()

    entered = getpass.getpass(f"{name}: ").strip()
    if entered:
        return entered
    raise SystemExit(f"{name} is required.")


def prompt_yes_no(message: str, default: bool = False) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    choice = input(f"{message} {suffix}: ").strip().lower()
    if not choice:
        return default
    return choice in {"y", "yes"}


def default_secrets_path(tools_root: pathlib.Path, google_account: Optional[str]) -> pathlib.Path:
    if google_account:
        return tools_root / "Auth" / f"{google_account.strip().lower()}.json"
    return tools_root / "Auth" / "secrets.json"


def get_secrets_account(secrets_path: pathlib.Path) -> Optional[str]:
    return infer_google_account(load_secrets(secrets_path))


def remove_secrets_file(secrets_path: pathlib.Path) -> None:
    if secrets_path.exists():
        secrets_path.unlink()
        print(f"Removed existing auth cache: {secrets_path}")


def run_auth_helper(args: argparse.Namespace, tools_root: pathlib.Path, secrets_path: pathlib.Path, google_account: Optional[str]) -> None:
    command = [
        sys.executable,
        str(tools_root / "provision_account_auth.py"),
        "--secrets-file",
        str(secrets_path),
        "--tools-root",
        str(tools_root),
    ]
    if google_account:
        command.extend(["--google-account", google_account])
    if args.skip_owner_key:
        command.append("--skip-owner-key")
    if args.yes:
        command.append("--yes")
    if args.backup_existing:
        command.append("--backup-existing")

    subprocess.run(command, cwd=str(tools_root), check=True)


def provision_backend(
    *,
    provisioning_url: str,
    provisioning_token: str,
    payload: dict,
    debug: bool,
) -> dict:
    payload_json = json.dumps(payload, separators=(",", ":"))
    body = base64.b64encode(payload_json.encode("utf-8")).decode("ascii")
    if debug:
        print(f"[debug] POST {provisioning_url}")
        print(f"[debug] payload bytes: {len(body.encode('utf-8'))}")
        print(f"[debug] google_account: {payload.get('google_account')}")
        print(f"[debug] has secrets_json_b64: {bool(payload.get('secrets_json_b64'))}")
        print("[debug] payload transport: text/plain base64")

    response = requests.post(
        provisioning_url,
        data=body,
        headers={
            "X-Provisioning-Token": provisioning_token,
            "Content-Type": "text/plain",
            "Accept": "application/json",
            "User-Agent": "GoogleFindMyTools-provisioner/1.0",
        },
        timeout=30,
    )
    if debug:
        print(f"[debug] response status: {response.status_code}")
        print(f"[debug] response content-type: {response.headers.get('content-type', '')}")
        print(f"[debug] response cf-ray: {response.headers.get('cf-ray', '')}")
        print(f"[debug] response bytes: {len(response.content)}")

    try:
        response.raise_for_status()
    except HTTPError as exc:
        if response.status_code == 401:
            raise ProvisioningUnauthorized("Provisioning token was rejected.") from exc
        body = response.text.strip()
        detail = f"\n{body}" if body else ""
        raise SystemExit(f"Provisioning request failed: HTTP {response.status_code}{detail}") from exc
    return response.json()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--google-account")
    parser.add_argument("--secrets-file")
    parser.add_argument("--tools-root")
    parser.add_argument(
        "--run-auth",
        action="store_true",
        help="Deprecated; fresh auth is now the default.",
    )
    parser.add_argument(
        "--fresh-auth",
        action="store_true",
        help="Remove the selected secrets file, run the login flow again, then upload it. This is the default.",
    )
    parser.add_argument(
        "--use-existing-auth",
        action="store_true",
        help="Upload the selected secrets file without removing it or running the login flow.",
    )
    parser.add_argument("--skip-owner-key", action="store_true")
    parser.add_argument("--yes", action="store_true")
    parser.add_argument("--backup-existing", action="store_true")
    parser.add_argument("--provisioning-url", default=os.getenv("PROVISIONING_URL", DEFAULT_PROVISIONING_URL))
    parser.add_argument("--provisioning-token", default=os.getenv("PROVISIONING_TOKEN"))
    parser.add_argument("--status", default="ready")
    parser.add_argument("--notes", default="")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    if args.use_existing_auth and (args.run_auth or args.fresh_auth):
        parser.error("--use-existing-auth cannot be combined with --run-auth or --fresh-auth")

    tools_root = pathlib.Path(args.tools_root).expanduser().resolve() if args.tools_root else pathlib.Path(__file__).resolve().parent
    provisioning_url = require_value("provisioning_url", args.provisioning_url)
    provisioning_token = args.provisioning_token

    while True:
        google_account = args.google_account.strip().lower() if args.google_account else None
        secrets_path = pathlib.Path(args.secrets_file).expanduser().resolve() if args.secrets_file else default_secrets_path(tools_root, google_account)

        should_run_auth = not args.use_existing_auth

        # With fresh authentication, do not carry the account name forward from
        # the cache that is about to be removed. The login flow must infer the
        # account actually selected in Chrome. An explicit --google-account is
        # still honored, and existing-auth mode still infers from its cache.
        if not should_run_auth and not google_account:
            google_account = get_secrets_account(secrets_path)

        if should_run_auth and not args.backup_existing:
            remove_secrets_file(secrets_path)

        if should_run_auth:
            run_auth_helper(args, tools_root, secrets_path, google_account)
            google_account = get_secrets_account(secrets_path)

        if not secrets_path.exists():
            raise SystemExit(f"Secrets file not found: {secrets_path}. Run without --use-existing-auth to log in again.")

        if not google_account:
            google_account = get_secrets_account(secrets_path)
        if not google_account:
            raise SystemExit(f"Could not infer Google account from secrets file: {secrets_path}")

        secret_object = load_secrets(secrets_path)
        secret_object["username"] = google_account
        secrets_json = json.dumps(secret_object, separators=(",", ":"))
        secrets_b64 = base64.b64encode(secrets_json.encode("utf-8")).decode("ascii")

        payload = {
            "google_account": google_account,
            "secrets_json_b64": secrets_b64,
            "status": args.status,
            "notes": args.notes,
        }
        print(f"Provisioning {google_account} through {provisioning_url}")
        for attempt in range(3):
            provisioning_token = prompt_secret("PROVISIONING_TOKEN", provisioning_token)
            try:
                result = provision_backend(
                    provisioning_url=provisioning_url,
                    provisioning_token=provisioning_token,
                    payload=payload,
                    debug=args.debug,
                )
                break
            except ProvisioningUnauthorized:
                attempts_left = 2 - attempt
                if attempts_left <= 0:
                    raise SystemExit("Provisioning token was rejected too many times.")
                print("Provisioning token was rejected. Please try again.")
                provisioning_token = None

        print(json.dumps(result, indent=2))

        if args.use_existing_auth:
            return 0
        if not prompt_yes_no("Register another Google account?"):
            return 0


if __name__ == "__main__":
    raise SystemExit(main())
